#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

float calculateIndex(float L, float S) {
    return 0.0588 * L - 0.296 * S - 15.8;
}

int countLetters(const char *text) {
    int count = 0;
    for (int i = 0; text[i]; i++) {
        if (isalpha(text[i])) {
            count++;
        }
    }
    return count;
}

int countSentences(const char *text) {
    int count = 0;
    for (int i = 0; text[i]; i++) {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?') {
            count++;
        }
    }
    return count;
}

int main(void) {
    string input = get_string("Enter a text: ");

    int numWords = 1;
    int numLetters = 0;
    int numSentences = 0;

    for (int i = 0; input[i]; i++) {
        if (isalpha(input[i])) {
            numLetters++;
        } else if (input[i] == ' ') {
            numWords++;
        } else if (input[i] == '.' || input[i] == '!' || input[i] == '?') {
            numSentences++;
        }
    }

    float L = (float) numLetters / numWords * 100;
    float S = (float) numSentences / numWords * 100;

    float index = calculateIndex(L, S);

    int gradeLevel = (int) (index + 0.5);

    if (gradeLevel >= 16) {
        printf("Grade 16+\n");
    } else if (gradeLevel < 1) {
        printf("Before Grade 1\n");
    } else {
        printf("Grade %d\n", gradeLevel);
    }

    return 0;
}
