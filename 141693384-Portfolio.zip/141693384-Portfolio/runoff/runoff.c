#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

#define MAX_CANDIDATES 3
#define MAX_VOTERS 3
#define MAX_RANKS 3

typedef struct
{
    char name[50];
    int eliminated;
    int votes;
} Candidate;

Candidate candidates[MAX_CANDIDATES];
int num_candidates;
int num_voters;

void add_candidate(char name[])
{
    strcpy(candidates[num_candidates].name, name);
    candidates[num_candidates].eliminated = 0;
    candidates[num_candidates].votes = 0;
    num_candidates++;
}

void vote(char ranks[][50], int num_ranks)
{
    for (int i = 0; i < num_ranks; i++)
    {
        for (int j = 0; j < num_candidates; j++)
        {
            if (!candidates[j].eliminated && strcmp(candidates[j].name, ranks[i]) == 0)
            {
                candidates[j].votes += num_ranks - i;
                break;
            }
        }
    }
}

int main(void)
{
    printf("Number of candidates: ");
    scanf("%d", &num_candidates);

    for (int i = 0; i < num_candidates; i++)
    {
        char name[50];
        printf("Candidate %d: ", i + 1);
        scanf("%s", name);
        add_candidate(name);
    }

    printf("Number of voters: ");
    scanf("%d", &num_voters);

    for (int i = 0; i < num_voters; i++)
    {
        char ranks[MAX_RANKS][50];
        printf("Voter %d:\n", i + 1);
        for (int j = 0; j < num_candidates; j++)
        {
            printf("Rank %d: ", j + 1);
            scanf("%s", ranks[j]);
        }
        vote(ranks, num_candidates);
    }

    // Display collected rankings
    for (int i = 0; i < num_candidates; i++)
    {
        printf("Candidate %s received %d votes.\n", candidates[i].name, candidates[i].votes);
    }

    return 0;
}
