#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

#define MAX_CANDIDATES 9

typedef struct
{
    char name[50];
    int votes;
} Candidate;

Candidate candidates[MAX_CANDIDATES];

int num_candidates;

void add_candidate(char name[])
{
    strcpy(candidates[num_candidates].name, name);
    candidates[num_candidates].votes = 0;
    num_candidates++;
}

void vote(char name[])
{
    for (int i = 0; i < num_candidates; i++)
    {
        if (strcmp(candidates[i].name, name) == 0)
        {
            candidates[i].votes++;
            break;
        }
    }
}

void find_winner()
{
    int max_votes = 0;
    char winner[50];

    for (int i = 0; i < num_candidates; i++)
    {
        if (candidates[i].votes > max_votes)
        {
            max_votes = candidates[i].votes;
            strcpy(winner, candidates[i].name);
        }
    }

    printf("Winner: %s\n", winner);
}

int main(void)
{
    add_candidate("Alice");
    add_candidate("Bob");
    add_candidate("Charlie");

    vote("Alice");
    vote("Bob");
    vote("Alice");
    vote("Charlie");

    find_winner();

    return 0;
}
