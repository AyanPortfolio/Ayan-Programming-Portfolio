#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

bool isValidKey(string key) {
    if (strlen(key) != 26) {
        return false;
    }

    bool seen[26] = {false};
    for (int i = 0; i < 26; i++) {
        if (!isalpha(key[i])) {
            return false;
        }
        int index = toupper(key[i]) - 'A';
        if (seen[index]) {
            return false;
        }
        seen[index] = true;
    }

    return true;
}

string encryptMessage(string message, string key) {
    string ciphertext = message;
    for (int i = 0; i < strlen(message); i++) {
        if (isalpha(message[i])) {
            char originalChar = isupper(message[i]) ? 'A' : 'a';
            int index = toupper(message[i]) - originalChar;
            ciphertext[i] = isupper(message[i]) ? toupper(key[index]) : tolower(key[index]);
        }
    }
    return ciphertext;
}

int main(int argc, string argv[]) {
    if (argc != 2) {
        printf("Usage: %s key\n", argv[0]);
        return 1;
    }

    string key = argv[1];
    if (!isValidKey(key)) {
        printf("Invalid key. The key must contain 26 unique alphabetic characters.\n");
        return 1;
    }

    string plaintext = get_string("plaintext: ");
    string ciphertext = encryptMessage(plaintext, key);

    printf("ciphertext: %s\n", ciphertext);

    return 0;
}
