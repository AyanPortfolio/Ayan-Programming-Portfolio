#include <stdio.h>
#include <math.h>

int main(void)
{
    const int QUARTER = 25;
    const int DIME = 10;
    const int NICKEL = 5;
    const int PENNY = 1;

    float change;
    printf("Change owed: ");
    scanf("%f", &change);

    int cents = round(change * 100);
    int coin_count = 0;

    coin_count += cents / QUARTER;
    cents %= QUARTER;

    coin_count += cents / DIME;
    cents %= DIME;

    coin_count += cents / NICKEL;
    cents %= NICKEL;

    coin_count += cents / PENNY;

    printf("%d\n", coin_count);

    return 0;
}
