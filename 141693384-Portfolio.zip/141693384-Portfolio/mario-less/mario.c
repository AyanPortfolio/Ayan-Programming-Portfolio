#include <cs50.h>
#include <stdio.h>

void print_pyramid(int height) {
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < height - i - 1; j++) {
            printf(" ");
        }
        for (int j = 0; j < i + 1; j++) {
            printf("#");
        }
        printf("\n");
    }
}

int main() {
    int height;

    do {
        height = get_int("Enter the height of the pyramid: ");
    } while (height < 1 || height > 8);

    print_pyramid(height);

    return 0;
}
