#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    uint8_t rgbtRed;
    uint8_t rgbtGreen;
    uint8_t rgbtBlue;
} RGBTRIPLE;

void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            uint8_t avg = (image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue) / 3;
            image[i][j].rgbtRed = avg;
            image[i][j].rgbtGreen = avg;
            image[i][j].rgbtBlue = avg;
        }
    }
}

void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            uint8_t originalRed = image[i][j].rgbtRed;
            uint8_t originalGreen = image[i][j].rgbtGreen;
            uint8_t originalBlue = image[i][j].rgbtBlue;

            int sepiaRed = 0.393 * originalRed + 0.769 * originalGreen + 0.189 * originalBlue;
            int sepiaGreen = 0.349 * originalRed + 0.686 * originalGreen + 0.168 * originalBlue;
            int sepiaBlue = 0.272 * originalRed + 0.534 * originalGreen + 0.131 * originalBlue;

            image[i][j].rgbtRed = (uint8_t)(sepiaRed > 255 ? 255 : sepiaRed);
            image[i][j].rgbtGreen = (uint8_t)(sepiaGreen > 255 ? 255 : sepiaGreen);
            image[i][j].rgbtBlue = (uint8_t)(sepiaBlue > 255 ? 255 : sepiaBlue);
        }
    }
}

void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            RGBTRIPLE temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
}

void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temp[height][width];
    memcpy(temp, image, sizeof(RGBTRIPLE) * height * width);

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int sumRed = 0, sumGreen = 0, sumBlue = 0;
            int count = 0;

            for (int di = -1; di <= 1; di++)
            {
                for (int dj = -1; dj <= 1; dj++)
                {
                    int ni = i + di;
                    int nj = j + dj;

                    if (ni >= 0 && ni < height && nj >= 0 && nj < width)
                    {
                        sumRed += temp[ni][nj].rgbtRed;
                        sumGreen += temp[ni][nj].rgbtGreen;
                        sumBlue += temp[ni][nj].rgbtBlue;
                        count++;
                    }
                }
            }

            image[i][j].rgbtRed = sumRed / count;
            image[i][j].rgbtGreen = sumGreen / count;
            image[i][j].rgbtBlue = sumBlue / count;
        }
    }
}

int main(void)
{

    grayscale(height, width, image);
    sepia(height, width, image);
    reflect(height, width, image);
    blur(height, width, image);


    return 0;
}
