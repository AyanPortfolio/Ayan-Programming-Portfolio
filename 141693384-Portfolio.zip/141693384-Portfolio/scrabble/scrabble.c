#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

int calculateScore(const char *word) {
    int score = 0;
    while (*word) {
        char c = toupper(*word);
        switch (c) {
            case 'A': case 'E': case 'I': case 'O': case 'U': case 'L': case 'N': case 'R': case 'S': case 'T':
                score += 1;
                break;
            case 'D': case 'G':
                score += 2;
                break;
            case 'B': case 'C': case 'M': case 'P':
                score += 3;
                break;
            case 'F': case 'H': case 'V': case 'W': case 'Y':
                score += 4;
                break;
            case 'K':
                score += 5;
                break;
            case 'J': case 'X':
                score += 8;
                break;
            case 'Q': case 'Z':
                score += 10;
                break;
        }
        word++;
    }
    return score;
}

int main(void) {
    string word1 = get_string("Enter Player 1's word: ");
    string word2 = get_string("Enter Player 2's word: ");

    int score1 = calculateScore(word1);
    int score2 = calculateScore(word2);

    if (score1 > score2) {
        printf("Player 1 wins!\n");
    } else if (score2 > score1) {
        printf("Player 2 wins!\n");
    } else {
        printf("Tie!\n");
    }

    return 0;
}
